"use strict";
(() => {
  // browser-extension/src/policy.ts
  function httpsOrigin(value) {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) throw new Error("\u4EC5\u652F\u6301 HTTPS \u7F51\u7AD9");
    return url.origin;
  }
  function editable(input) {
    const style = getComputedStyle(input);
    return !input.disabled && !input.readOnly && input.type !== "hidden" && !input.closest("[hidden], [inert]") && style.display !== "none" && style.visibility !== "hidden" && style.visibility !== "collapse";
  }
  function hasAutocomplete(input, token) {
    return input.autocomplete.toLowerCase().split(/\s+/).includes(token);
  }
  function selectLoginFields(root) {
    const focused = root.activeElement instanceof HTMLInputElement ? root.activeElement : null;
    const scope = focused?.form ?? root;
    const fields = Array.from(scope.querySelectorAll("input")).filter(editable);
    const loginFields = fields.filter((f) => ["text", "email", "tel", "password"].includes(f.type));
    if (new Set(loginFields.map((f) => f.form)).size > 1) throw new Error("\u767B\u5F55\u5B57\u6BB5\u6765\u81EA\u4E0D\u540C\u8868\u5355\uFF0C\u8BF7\u5148\u805A\u7126\u76EE\u6807\u8868\u5355");
    if (fields.some((f) => hasAutocomplete(f, "new-password"))) throw new Error("\u4E0D\u81EA\u52A8\u586B\u5145\u6CE8\u518C\u6216\u4FEE\u6539\u5BC6\u7801\u8868\u5355");
    const passwords = fields.filter((f) => f.type === "password");
    if (passwords.length > 1) throw new Error("\u5BC6\u7801\u6846\u4E0D\u660E\u786E\uFF0C\u8BF7\u805A\u7126\u76EE\u6807\u767B\u5F55\u8868\u5355");
    const texts = fields.filter((f) => ["text", "email", "tel"].includes(f.type) && !hasAutocomplete(f, "one-time-code"));
    const explicit = texts.filter((f) => hasAutocomplete(f, "username") || f.type === "email" || /user|email|account|login/i.test(`${f.name} ${f.id}`));
    const username = explicit.length === 1 ? explicit[0] : texts.length === 1 ? texts[0] : null;
    if (!passwords.length && !username) throw new Error("\u6CA1\u6709\u627E\u5230\u53EF\u7F16\u8F91\u7684\u767B\u5F55\u5B57\u6BB5");
    if (passwords.length && texts.length > 1 && !username) throw new Error("\u8D26\u53F7\u6846\u4E0D\u660E\u786E\uFF0C\u8BF7\u5148\u805A\u7126\u76EE\u6807\u8868\u5355");
    return { username, password: passwords[0] ?? null };
  }

  // browser-extension/src/content.ts
  var contentNonce = crypto.randomUUID();
  var lastInput = null;
  function isEditable(element) {
    return element instanceof HTMLInputElement && ["text", "email", "tel", "password"].includes(element.type) && !element.disabled && !element.readOnly && !hasAutocomplete(element, "one-time-code") && !hasAutocomplete(element, "new-password");
  }
  function visible(input) {
    const bounds = input.getBoundingClientRect(), style = getComputedStyle(input);
    return input.isConnected && !input.closest("[hidden], [inert]") && bounds.width > 0 && bounds.height > 0 && style.visibility === "visible" && style.display !== "none";
  }
  function fillValue(input, value) {
    if (!isEditable(input) || !visible(input)) throw new Error("\u76EE\u6807\u8F93\u5165\u6846\u5DF2\u4E0D\u53EF\u7F16\u8F91");
    input.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (!setter) throw new Error("\u5F53\u524D\u8F93\u5165\u6846\u4E0D\u652F\u6301\u586B\u5145");
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  document.addEventListener("focusin", (event) => {
    if (isEditable(event.target instanceof Element ? event.target : null)) lastInput = event.target;
    void chrome.runtime.sendMessage({ type: "codebook-focus" }).catch(() => {
    });
  }, true);
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || window !== window.top) return;
    if (message?.type === "codebook-probe") {
      const input = isEditable(document.activeElement) ? document.activeElement : lastInput;
      respond({ contentNonce, editable: !!input && isEditable(input) && visible(input) });
      return;
    }
    if (message?.type !== "codebook-fill") return;
    try {
      if (message.contentNonce !== contentNonce || message.origin !== httpsOrigin(location.href) || document.visibilityState !== "visible" || !document.hasFocus()) throw new Error("\u9875\u9762\u6216\u7126\u70B9\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u8C03\u7528");
      if (typeof message.username !== "string" || typeof message.password !== "string" || message.username.length > 4096 || message.password.length > 4096) throw new Error("\u8D26\u6237\u6570\u636E\u65E0\u6548");
      if (message.mode === "username" || message.mode === "password") {
        const input = document.activeElement instanceof HTMLInputElement ? document.activeElement : lastInput;
        if (!isEditable(input)) throw new Error("\u8BF7\u5148\u70B9\u51FB\u53EF\u586B\u5145\u7684\u767B\u5F55\u8F93\u5165\u6846");
        fillValue(input, message.mode === "username" ? message.username : message.password);
      } else if (message.mode === "auto") {
        if (lastInput?.isConnected) lastInput.focus();
        const { username, password } = selectLoginFields(document);
        if (username && !visible(username) || password && !visible(password)) throw new Error("\u767B\u5F55\u5B57\u6BB5\u4E0D\u53EF\u89C1");
        if (username) fillValue(username, message.username);
        if (password) fillValue(password, message.password);
      } else throw new Error("\u4E0D\u652F\u6301\u6B64\u586B\u5145\u65B9\u5F0F");
      respond({ ok: true });
    } catch (error) {
      respond({ ok: false, error: error instanceof Error ? error.message : "\u586B\u5145\u5931\u8D25" });
    } finally {
      message.username = "";
      message.password = "";
    }
  });
})();
