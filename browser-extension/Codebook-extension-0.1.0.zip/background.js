"use strict";
(() => {
  // browser-extension/src/policy.ts
  function httpsOrigin(value) {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) throw new Error("\u4EC5\u652F\u6301 HTTPS \u7F51\u7AD9");
    return url.origin;
  }
  function sameDocument(expected, actual) {
    try {
      return expected.tabId === actual.tabId && expected.documentId === actual.documentId && !!expected.documentId && expected.origin === actual.origin && httpsOrigin(actual.origin) === actual.origin;
    } catch {
      return false;
    }
  }

  // browser-extension/src/background.ts
  var port = null;
  var target = null;
  var lastFocus = Date.now();
  var browserName = navigator.userAgent.includes("Edg/") ? "Microsoft Edge" : "Google Chrome";
  function badge(text, color, title) {
    void chrome.action.setBadgeText({ text });
    void chrome.action.setBadgeBackgroundColor({ color });
    void chrome.action.setTitle({ title });
  }
  function connect() {
    if (port) return;
    try {
      const connection = chrome.runtime.connectNative("local.codebook.host");
      port = connection;
      connection.onMessage.addListener((message) => {
        void receive(message);
      });
      connection.onDisconnect.addListener(() => {
        const reason = chrome.runtime.lastError?.message;
        port = null;
        target = null;
        badge("!", "#97764a", reason ? `Codebook \u672A\u8FDE\u63A5\uFF1A${reason}` : "Codebook \u672A\u8FDE\u63A5");
      });
      connection.postMessage({ type: "hello", browser: browserName });
    } catch {
      port = null;
      badge("!", "#97764a", "\u8BF7\u5148\u5B89\u88C5\u5E76\u8FD0\u884C Codebook");
    }
  }
  async function currentIdentity(tabId) {
    const tab = await chrome.tabs.get(tabId);
    const frame = await chrome.webNavigation.getFrame({ tabId, frameId: 0 });
    if (!tab.url || !frame?.documentId || !frame.url) throw new Error("\u9875\u9762\u5C1A\u672A\u5C31\u7EEA");
    const origin = httpsOrigin(tab.url);
    if (origin !== httpsOrigin(frame.url)) throw new Error("\u9875\u9762\u6765\u6E90\u53D8\u5316");
    return { tabId, documentId: frame.documentId, origin };
  }
  async function refreshContext(requestFill = false) {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const tab = tabs[0];
    if (!tab?.id || tab.windowId === void 0 || !tab.url) throw new Error("\u6CA1\u6709\u53EF\u7528\u7684\u6D3B\u52A8\u9875\u9762");
    const identity = await currentIdentity(tab.id);
    const window = await chrome.windows.get(tab.windowId);
    const probe = await chrome.tabs.sendMessage(tab.id, { type: "codebook-probe" }, { documentId: identity.documentId });
    if (typeof probe?.contentNonce !== "string") throw new Error("\u9875\u9762\u6269\u5C55\u5C1A\u672A\u5C31\u7EEA");
    target = { ...identity, windowId: tab.windowId, contentNonce: probe.contentNonce, editable: probe.editable === true, active: window.focused === true, focusedAt: lastFocus, browser: browserName };
    connect();
    port?.postMessage({ type: requestFill ? "requestFill" : "context", target });
  }
  async function receive(message) {
    if (message.type === "status") {
      badge(message.paired ? "" : "?", "#23795f", message.paired ? "\u4ECE Codebook \u9009\u62E9\u8D26\u6237" : "\u8BF7\u5728 Codebook \u8BBE\u7F6E\u4E2D\u5141\u8BB8\u6B64\u6D4F\u89C8\u5668\u8FDE\u63A5");
      return;
    }
    if (message.type === "error") {
      badge("!", "#a95c4c", message.message ?? "Codebook \u64CD\u4F5C\u672A\u5B8C\u6210");
      return;
    }
    if (message.type === "queryContext") {
      try {
        await refreshContext();
      } catch {
        port?.postMessage({ type: "inactive" });
      }
      return;
    }
    if (message.type !== "fill" || !message.target || !message.token) return;
    try {
      const expected = message.target;
      if (!target || target.contentNonce !== expected.contentNonce || !sameDocument(expected, await currentIdentity(expected.tabId))) throw new Error("\u9875\u9762\u5DF2\u7ECF\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8C03\u7528");
      const tab = await chrome.tabs.get(expected.tabId);
      const win = await chrome.windows.get(expected.windowId);
      if (!tab.active || tab.windowId !== expected.windowId || !win.focused) throw new Error("\u76EE\u6807\u6807\u7B7E\u9875\u5DF2\u4E0D\u5728\u524D\u53F0");
      const reply = await chrome.tabs.sendMessage(expected.tabId, {
        type: "codebook-fill",
        origin: expected.origin,
        contentNonce: expected.contentNonce,
        username: message.username,
        password: message.password,
        mode: message.mode
      }, { documentId: expected.documentId });
      if (!reply?.ok) throw new Error(reply?.error ?? "\u65E0\u6CD5\u8BC6\u522B\u767B\u5F55\u6846");
      port?.postMessage({ type: "fillResult", token: message.token, ok: true });
      badge("", "#23795f", "\u8D26\u6237\u5DF2\u586B\u5165\uFF0C\u8BF7\u81EA\u884C\u70B9\u51FB\u767B\u5F55");
    } catch (error) {
      const reason = error instanceof Error ? error.message : "\u586B\u5145\u5931\u8D25";
      port?.postMessage({ type: "fillResult", token: message.token, ok: false, message: reason });
      badge("!", "#a95c4c", reason);
    } finally {
      message.username = "";
      message.password = "";
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== "codebook-focus" || sender.id !== chrome.runtime.id || sender.frameId !== 0 || !sender.tab?.id) return;
    void (async () => {
      try {
        const actual = await currentIdentity(sender.tab.id);
        if (sender.documentId !== actual.documentId || !sender.url || httpsOrigin(sender.url) !== actual.origin) return;
        lastFocus = Date.now();
        await refreshContext();
        respond({ ok: true });
      } catch {
        respond({ ok: false });
      }
    })();
    return true;
  });
  chrome.action.onClicked.addListener(() => {
    lastFocus = Date.now();
    connect();
    void refreshContext(true).catch((error) => badge("!", "#a95c4c", error instanceof Error ? error.message : "\u65E0\u6CD5\u8C03\u7528"));
  });
  chrome.tabs.onActivated.addListener(() => {
    lastFocus = Date.now();
    void refreshContext().catch(() => {
      target = null;
      port?.postMessage({ type: "inactive" });
    });
  });
  chrome.tabs.onUpdated.addListener((_id, change) => {
    if (change.status === "complete") void refreshContext().catch(() => {
    });
    else if (change.status === "loading") {
      target = null;
      port?.postMessage({ type: "inactive" });
    }
  });
  chrome.windows.onFocusChanged.addListener((id) => {
    if (id === chrome.windows.WINDOW_ID_NONE) {
      if (target) {
        target.active = false;
        port?.postMessage({ type: "context", target });
      }
    } else {
      lastFocus = Date.now();
      void refreshContext().catch(() => {
      });
    }
  });
  chrome.alarms.create("codebook-heartbeat", { periodInMinutes: 0.5 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "codebook-heartbeat") {
      connect();
      void refreshContext().catch(() => {
      });
    }
  });
  connect();
  void refreshContext().catch(() => {
  });
})();
